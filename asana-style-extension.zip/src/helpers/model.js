export const StorageId = Object.freeze({
  TaskCompletedStyle: 'ase-task-complete-style-input',
  DarkModeStyle: 'ase-dark-mode-style-input',
});

export const Style = Object.freeze({
  TaskCompleted: 'task-completed-style',
  DarkMode: 'dark-mode-style',
});
